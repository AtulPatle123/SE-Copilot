const replace = require('replace-in-file');
const semver = require('semver');
const path = require('path');

// retrieve information from package.json
const pkgInfo = require('../package.json');

// function that return true if version should be tagged as snapshot
const isSnapshotVersion = (version) => {
  return version.indexOf('beta') > -1;
};

// read version package info
const currentVersion = pkgInfo.version;

// define target version for pom files
let targetVersion = currentVersion;
if (isSnapshotVersion(currentVersion)) {
  targetVersion += '-SNAPSHOT';
}

// set options for replace in file
const deployPath = path.resolve(path.join(__dirname, '../deployment'));
const options = {
  'files': [
    `${deployPath}/pom.xml`,
    `${deployPath}/*/pom.xml`
  ],
  'from': /<version>[\s\S]*?<\/version>/,
  'to': `<version>${targetVersion}<\/version>`,
};

// update all pom files
replace(options)
  .then(changes => {
    if (!changes || changes.length === 0) {
      console.info('[INFO] Pom files are already up-to-date, nothing changed');
    } else {
      console.info('[SUCCESS] Updated pom.xml files to new version', targetVersion, '\n' + changes.join('\n'));
    }
  })
  .catch(error => {
    console.error('[ERROR] While replacing POM files:', error);
    process.exitCode = 1;
  });
