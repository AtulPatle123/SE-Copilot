/**
 * Deploy script adopted from https://github.com/sindresorhus/np
 * MIT License (c) Sindre Sorhus (sindresorhus.com)
 */

/**
 * To install dependencies run: npm i -D ansi-colors@3.2.4 execa@1.0.0 inquirer@6.2.2 listr@0.14.3 semver@5.6.0
 */
const color = require('ansi-colors');
const execa = require('execa');
const inquirer = require('inquirer');
const Listr = require('listr');
const fs = require('fs');
const path = require('path');
const semver = require('semver');

const rootDir = path.join(__dirname, '../');
const packageJsonPath = path.join(rootDir, 'package.json');

// needed because of bug in NPM: https://github.com/npm/npm/issues/20979
const execaOptions = {
  env: {
    NO_UPDATE_NOTIFIER: true,
  },
};

function runTasks(opts) {
  const pkg = readPkg();

  const tasks = [];
  let newVersion = getNewVersion(pkg.version, opts.version);
  let tagPrefix = null;

  tasks.push(
    {
      title: 'Validate version',
      task: () => {
        if (!isValidVersionInput(opts.version)) {
          throw new Error(
            `Version should be either ${SEMVER_INCREMENTS.join(', ')}, or a valid semver version.`
          );
        }

        if (!isVersionGreater(pkg.version, newVersion)) {
          throw new Error(
            `New version \`${newVersion}\` should be higher than current version \`${pkg.version}\``
          );
        }
      },
    },
    {
      title: 'Check git tag existence',
      task: () =>
        execa('git', ['fetch'], execaOptions)
          .then(() => {
            return execa.stdout('npm', ['config', 'get', 'tag-version-prefix'], execaOptions);
          })
          .then(output => {
            return (tagPrefix = output);
          })
          .then(() => {
            return execa.stdout(
              'git',
              ['rev-parse', '--quiet', '--verify', `refs/tags/${tagPrefix}${newVersion}`],
              execaOptions
            );
          })
          .then(
            output => {
              if (output) {
                throw new Error(`Git tag \`${tagPrefix}${newVersion}\` already exists.`);
              }
            },
            err => {
              // Command fails with code 1 and no output if the tag does not exist, even though `--quiet` is provided
              // https://github.com/sindresorhus/np/pull/73#discussion_r72385685
              if (err.stdout !== '' || err.stderr !== '') {
                throw err;
              }
            }
          ),
    },
    {
      title: 'Check local working tree',
      task: () =>
        execa.stdout('git', ['status', '--porcelain'], execaOptions).then(status => {
          if (status !== '') {
            throw new Error('Unclean working tree. Commit or stash changes first.');
          }
        }),
    },
    {
      title: 'Check remote history',
      task: () =>
        execa
          .stdout('git', ['rev-list', '--count', '--left-only', '@{u}...HEAD'], execaOptions)
          .then(result => {
            if (result !== '0' && process.argv.slice(2).indexOf('--any-branch') === -1) {
              throw new Error('Remote history differs. Please pull changes.');
            }
          }),
    }
  );

  tasks.push(
    {
      title: 'Run build',
      task: () =>
        execa(
          'npm',
          ['run', 'build'],
          Object.assign({}, execaOptions, { cwd: rootDir })
        ),
    },
    // {
    //   title: 'Run tests',
    //   task: () => execa('npm', ['run', 'test'], Object.assign({}, execaOptions, { cwd: rootDir })),
    // },
    {
      title: 'Bump version',
      task: () =>
        execa(
          'npm',
          ['version', opts.version, '-m', 'release v%s'],
          Object.assign({}, execaOptions, { cwd: rootDir })
        ),
    }
  );

  if (opts.branch) {
    tasks.push({
      title: 'Create release branch',
      task: () =>
        execa(
          'git',
          ['branch', `releases/${opts.version}`],
          Object.assign({}, execaOptions, { cwd: rootDir })
        ),
    });
  }

  const listr = new Listr(tasks, { showSubtasks: false });

  return listr
    .run()
    .then(() => {
      console.log(`\n ${pkg.name} ${newVersion} prepared, check the diffs and publish 🕵️\n`);
    })
    .catch(err => {
      console.log('\n', color.red(err), '\n');
      process.exit(1);
    });
}

function prepareUI() {
  const pkg = readPkg();
  const oldVersion = pkg.version;

  console.log(
    `\nPrepare to publish a new version of ${color.bold.magenta(pkg.name)} ${color.dim(
      `(${oldVersion})`
    )}\n`
  );

  const prompts = [
    {
      type: 'list',
      name: 'version',
      message: 'Select semver increment or specify new version',
      pageSize: SEMVER_INCREMENTS.length + 2,
      choices: SEMVER_INCREMENTS.filter(choice => {
        if (!semver.prerelease(oldVersion)) {
          return choice.increment !== 'prerelease';
        }

        return true;
      })
        .map(inc => ({
          name: `${inc.text} (${prettyVersionDiff(oldVersion, inc.increment)})`,
          value: getNewVersion(oldVersion, inc.increment),
        }))
        .concat([
          new inquirer.Separator(),
          {
            name: 'Other (specify)',
            value: null,
          },
        ]),
      filter: input => (isValidVersionInput(input) ? getNewVersion(oldVersion, input) : input),
    },
    {
      type: 'input',
      name: 'version',
      message: 'Version',
      when: answers => !answers.version,
      filter: input => (isValidVersionInput(input) ? getNewVersion(oldVersion, input) : input),
      validate: input => {
        if (!isValidVersionInput(input)) {
          return 'Please specify a valid semver, for example, `1.2.3`. See http://semver.org';
        } else if (!isVersionGreater(oldVersion, input)) {
          return `Version must be greater than ${oldVersion}`;
        }

        return true;
      },
    },
    {
      type: 'confirm',
      name: 'branch',
      message: answers => {
        return `Do you want to create branch "${color.cyan('releases/' + answers.version)}" ?`;
      },
      when: answers => !semver.prerelease(answers.version),
    },
    {
      type: 'confirm',
      name: 'confirm',
      message: answers => {
        return `Will bump from ${color.cyan(oldVersion)} to ${color.cyan(
          answers.version
        )}. Continue?`;
      },
    },
  ];

  return inquirer
    .prompt(prompts)
    .then(answers => {
      if (answers.confirm) {
        runTasks(answers);
      } else {
        throw new Error('Canceled');
      }
    })
    .catch(err => {
      console.log('\n', color.red(err), '\n');
      process.exit(1);
    });
}

const SEMVER_INCREMENTS = [
  {
    text: 'increment',
    increment: 'prerelease',
  },
  {
    text: 'start patch',
    increment: 'prepatch',
  },
  {
    text: 'start minor',
    increment: 'preminor',
  },
  {
    text: 'release',
    increment: 'release',
  },
];

const isValidVersion = input => Boolean(semver.valid(input));

const isValidVersionInput = input =>
  SEMVER_INCREMENTS.findIndex(inc => inc.increment === input) !== -1 || isValidVersion(input);

function getNewVersion(oldVersion, input) {
  if (!isValidVersionInput(input)) {
    throw new Error(
      `Version should be either ${SEMVER_INCREMENTS.join(', ')} or a valid semver version.`
    );
  }

  if (input === 'release') {
    return [semver.major(oldVersion), semver.minor(oldVersion), semver.patch(oldVersion)].join('.');
  }

  if (input.indexOf('pre') > -1) {
    return semver.inc(oldVersion, input, 'beta');
  }

  if (isValidVersion(input)) {
    return input;
  }

  return semver.inc(oldVersion, input);
}

const isVersionGreater = (oldVersion, newVersion) => {
  if (!isValidVersion(newVersion)) {
    throw new Error('Version should be a valid semver version.');
  }

  return semver.gt(newVersion, oldVersion);
};

const isVersionLower = (oldVersion, newVersion) => {
  if (!isValidVersion(newVersion)) {
    throw new Error('Version should be a valid semver version.');
  }

  return semver.lt(newVersion, oldVersion);
};

const satisfies = (version, range) => semver.satisfies(version, range);

const readPkg = () => {
  return JSON.parse(fs.readFileSync(packageJsonPath, 'utf8'));
};

function prettyVersionDiff(oldVersion, inc) {
  const newVersion = getNewVersion(oldVersion, inc).split('.');
  oldVersion = oldVersion.split('.');
  let firstVersionChange = false;
  const output = [];

  for (let i = 0; i < newVersion.length; i++) {
    if (newVersion[i] !== oldVersion[i] && !firstVersionChange) {
      output.push(`${color.dim.cyan(newVersion[i])}`);
      firstVersionChange = true;
    } else if (newVersion[i].indexOf('-') >= 1) {
      let preVersion = [];
      preVersion = newVersion[i].split('-');
      output.push(`${color.dim.cyan(`${preVersion[0]}-${preVersion[1]}`)}`);
    } else {
      output.push(color.reset.dim(newVersion[i]));
    }
  }
  return output.join(color.reset.dim('.'));
}

prepareUI();
