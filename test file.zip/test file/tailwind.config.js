const { fontFamily } = require('tailwindcss/defaultTheme')
const colors = require('tailwindcss/colors')

module.exports = {
  content: [
    './docs/**/*.{html,md,vue,js}',
    // globs skip dot-folders unless named explicitly
    './docs/.vuepress/*.{js,mjs}',
    './docs/.vuepress/{theme,components}/**/*.{vue,js,mjs}',
  ],
  theme: {
    fontFamily: {
      sans: ['Nunito', '-apple-system', 'BlinkMacSystemFont', 'Segoe UI', 'Roboto', 'Helvetica Neue', 'Arial', 'Noto Sans', 'sans-serif', 'Apple Color Emoji', 'Segoe UI Emoji', 'Segoe UI Symbol', 'Noto Color Emoji'],
      mono: fontFamily.mono,
    },
    screens: {
      sm: '640px',
      md: '768px',
      lg: '1024px',
      xl: '1200px',
    },
    container: {
      center: true,
      padding: '1rem',
    },
    colors: {
      black: colors.black,
      white: colors.white,
      gray: {
        100: '#F7F7F7',
        200: '#E6E6E6',
        300: '#CBCBCB',
        400: '#9FA0A4',
        500: '#626469',
        600: '#505559',
        700: '#434343',
        800: '#333333',
      },
      green: {
        400: '#3dcd58',
        500: '#32AD3C',
        600: '#009530',
        700: '#007626',
      },
      blue: {
        400: '#42B4E6',
        500: '#219BFD',
      },
      orange: '#E47F00',
      red: '#DC0A0A',
    },
    extend: {
      // Tailwind 1 default border color (gray-300)
      borderColor: {
        DEFAULT: '#CBCBCB',
      },
    },
  },
  plugins: [],
}
