# Widget Documentation App
### Installation
``` console
npm install
``` 

### Run server
``` console
npm start 
``` 

### Update documentation version
Update the version name in the `package.json` file and run:
``` console
npm update-pom-files
```

**Please be in line with the widget's version:<br />
If the widget's version is 2.21.2 the documentation version must start by 2.21**

### Release
* dev : each push on develop branch will update the following website : https://selectconfig-widget-dev.schneider-electric.com/docs/#/home
* prod : First you need to deploy the project to the Schneider Electric's Artifactory `npm maven-deploy`, next create a [DII Jira ticket](https://schneider-electric-se.atlassian.net/secure/RapidBoard.jspa?rapidView=333&projectKey=DII) to request the deployment on the bucket :AWS_S3_BUCKET=dces-selectandconfig-widget-prd.<br />
<br />
An example of the description of the Jira Ticket:<br />
>Please deploy to Production the Select & Config documentation website:<br />
dces-selectconfig-release-local/com/schneiderelectric/dces/widget/install-sc-widget-docs/XXX/install-sc-widget-docs-XXX.tar.gz to the bucket : AWS_S3_BUCKET=dces-selectandconfig-widget-prd.
<br />
As explain in the following ticket : https://schneider-electric-se.atlassian.net/browse/DII-1849 no DoD mandatory

Please note that XXX is the documentation version needed to be deploy.
